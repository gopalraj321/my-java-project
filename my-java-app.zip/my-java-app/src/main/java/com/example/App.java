package com.example;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Jenkins CI/CD with Maven & SonarQube!");
    }

    public static String greet() {
        return "Hello from greet() method!";
    }
}
